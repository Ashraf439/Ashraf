# Guess the shapes with python
#### Video Demo:  <URL https://youtu.be/a2FmMOAFTcY?si=zO0UjKtn3Q-qakEN>
#### Description:

- Some random shapes will be generated with the help of Python built-in module random.
- After generating the shapes, you need to guess.
- If you guess it correctly, the score will increase by one.
- Otherwise, it will say, "Sorry, the correct shape was {circle|triangle|square}."
- After completing the game, it will display your score out of five.
- It will ask whether you want to continue the game or not. If not, the game will terminate.