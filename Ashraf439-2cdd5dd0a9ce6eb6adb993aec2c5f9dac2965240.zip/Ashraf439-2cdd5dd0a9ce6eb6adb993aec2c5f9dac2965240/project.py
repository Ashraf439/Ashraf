import random

def main():
    # BY default score is set to zero
    player_score = 0
    # There will be 5 rounds
    rounds = 5
    print("\nThe rules are pretty simple: all you need to do is guess the shape\n")
    # If we press 's', the game will start
    while True:
        start = input("Press 's' to start and 'e' to stop: ").strip()

        if start == "s":
            player_score += get_score(rounds)
            print(f"Game over! Your score: {player_score}/{rounds}")
            # After the shapes, it'll display the score, and if we want to exit, we need to press 'e'
            play_again = input("If you want to play again, press 's'. To exit, press 'e': ")
            if play_again == 'e':
                break

# As you can see, I've made some basic shapes like
def pyramid():
    n = 5
    for i in range(n):
        print(" " * (n - i - 1) + "*" * (2 * i + 1))
    print("\n")

def square():
    n = 5
    for i in range(n):
        i = n
        print("*" * i)
    print("\n")

def circle():
    dia = 7
    r = (dia / 2) - 0.5
    for i in range(dia):
        for j in range(dia):
            x = i - r
            y = j - r
            if x * x + y * y <= r * r + 1:
                print("*", end=' ')
            else:
                print(" ", end=' ')
        print()
    print("\n")

def triangle():
    n = 5
    for i in range(n):
        i += 1
        print("*" * i)

def get_score(rounds):
    rounds = int(rounds)
    player_score = 0

    for _ in range(rounds):
        shape = random.choice(["pyramid", "square", "circle", "triangle"])
        if shape == "pyramid":
            pyramid()
        elif shape == "circle":
            circle()
        elif shape == "square":
            square()
        elif shape == "triangle":
            triangle()

        guess = input("Guess the shape: ").strip().lower()

        if guess == shape:
            player_score += 1
            print("Correct!\n")
        # if you guess correctly, the score will increase
        else:
            # Or else it'll display the correct shape
            print(f"Sorry, the correct shape was {shape}\n")

    return player_score

if __name__ == "__main__":
    main()
