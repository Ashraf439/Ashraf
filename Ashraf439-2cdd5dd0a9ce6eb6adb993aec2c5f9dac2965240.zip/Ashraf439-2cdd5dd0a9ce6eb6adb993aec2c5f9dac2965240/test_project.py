import unittest
from project import get_score
#Here we're testing get_score 
class TestGetScore(unittest.TestCase):
    def test_correct_guess(self):
        # Test when the guess is correct
        result = get_score(5)
        self.assertIsInstance(result, int)  # Check if the result is an integer

    def test_incorrect_guess(self):
        # Test when the guess is incorrect
        result = get_score(3)
        self.assertIsInstance(result, int)  # Check if the result is an integer

if __name__ == "__main__":
    unittest.main()
